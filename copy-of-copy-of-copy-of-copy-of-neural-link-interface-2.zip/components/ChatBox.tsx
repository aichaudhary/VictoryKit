
import React, { useState, useRef, useEffect } from 'react';
import { Send, Upload, Mic, ThumbsUp, ThumbsDown, Copy, Share2, Volume2, Check, ExternalLink, Globe, MessageSquare, Edit3, Monitor, FileCode, FileText, Layout, PlayCircle, Image as ImageIcon, Video } from 'lucide-react';
import { Message, SettingsState, WorkspaceMode } from '../types';

interface ChatBoxProps {
  messages: Message[];
  isThinking: boolean;
  onSend: (text: string) => void;
  agentSettings: SettingsState;
  onUpdateSettings: (settings: SettingsState) => void;
}

const ChatBox: React.FC<ChatBoxProps> = ({ messages, isThinking, onSend, agentSettings, onUpdateSettings }) => {
  const [inputText, setInputText] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current && agentSettings.workspaceMode === 'CHAT') {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isThinking, agentSettings.workspaceMode]);

  const handleSend = () => {
    if (!inputText.trim() || isThinking) return;
    onSend(inputText.trim());
    setInputText("");
  };

  const setWorkspace = (mode: WorkspaceMode) => {
    onUpdateSettings({ ...agentSettings, workspaceMode: mode });
  };

  const mountPortal = (url: string) => {
    onUpdateSettings({ ...agentSettings, portalUrl: url, workspaceMode: 'PORTAL' });
  };

  const handleCanvasEdit = (content: string) => {
    onUpdateSettings({
      ...agentSettings,
      canvas: { ...agentSettings.canvas, content }
    });
  };

  const renderCanvasContent = () => {
    const { type, content, language } = agentSettings.canvas;

    switch (type) {
      case 'html':
        return (
          <div className="w-full h-full bg-white rounded shadow-2xl overflow-hidden border border-gray-300 ring-4 ring-black">
            <iframe srcDoc={content} className="w-full h-full border-none" title="Canvas Preview" />
          </div>
        );
      case 'video':
        return (
          <div className="w-full h-full bg-black rounded flex items-center justify-center overflow-hidden">
             {content.includes('youtube.com') || content.includes('vimeo.com') ? (
                <iframe src={content} className="w-full h-full aspect-video" allowFullScreen title="Neural Video Sync" />
             ) : (
                <video src={content} controls className="max-w-full max-h-full" />
             )}
          </div>
        );
      case 'image':
        return (
          <div className="w-full h-full flex items-center justify-center bg-[#050505] p-4">
            <img src={content} alt="Sync Asset" className="max-w-full max-h-full object-contain rounded shadow-[0_0_50px_rgba(34,211,238,0.2)]" />
          </div>
        );
      case 'code':
      case 'text':
      default:
        return (
          <textarea 
            value={content}
            onChange={(e) => handleCanvasEdit(e.target.value)}
            spellCheck="false"
            className={`w-full h-full bg-transparent outline-none resize-none leading-relaxed custom-scrollbar ${type === 'code' ? 'font-mono text-cyan-300/80 text-sm' : 'font-serif text-gray-400 text-lg'}`}
            placeholder="Start typing or let the agent synthesize content here..."
          />
        );
    }
  };

  return (
    <main className="relative flex-grow bg-black/20 flex flex-col overflow-hidden z-10 m-2 sm:m-4 rounded-lg shadow-[0_0_40px_rgba(0,0,0,0.6)] border border-gray-800/40 backdrop-blur-md">
      {/* Workspace Tabs - Matrix Themed */}
      <div className="flex items-center justify-between bg-[#0d0d0d] border-b border-gray-800/60 p-1">
        <div className="flex items-center gap-1">
          <button 
            onClick={() => setWorkspace('CHAT')}
            className={`flex items-center gap-2 px-4 py-2 text-[10px] font-bold tracking-widest uppercase transition-all rounded ${agentSettings.workspaceMode === 'CHAT' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shadow-[0_0_15px_rgba(16,185,129,0.1)]' : 'text-gray-600 hover:text-gray-400'}`}
          >
            <MessageSquare size={14} /> LINK_CHAT
          </button>
          <button 
            onClick={() => setWorkspace('PORTAL')}
            className={`flex items-center gap-2 px-4 py-2 text-[10px] font-bold tracking-widest uppercase transition-all rounded ${agentSettings.workspaceMode === 'PORTAL' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 shadow-[0_0_15px_rgba(34,211,238,0.1)]' : 'text-gray-600 hover:text-gray-400'}`}
          >
            <Globe size={14} /> NEURAL_PORTAL
          </button>
          <button 
            onClick={() => setWorkspace('CANVAS')}
            className={`flex items-center gap-2 px-4 py-2 text-[10px] font-bold tracking-widest uppercase transition-all rounded ${agentSettings.workspaceMode === 'CANVAS' ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20 shadow-[0_0_15px_rgba(168,85,247,0.1)]' : 'text-gray-600 hover:text-gray-400'}`}
          >
            <Edit3 size={14} /> CANVAS_SYNC
          </button>
        </div>
        <div className="flex items-center gap-3 pr-4 text-[9px] text-gray-700 font-mono tracking-widest uppercase hidden lg:flex">
          <Monitor size={12} className="text-emerald-900" /> STATUS: {agentSettings.workspaceMode}
        </div>
      </div>
      
      <div className="flex-grow flex flex-col relative overflow-hidden bg-black/10">
        {/* CHAT VIEW */}
        <div className={`absolute inset-0 flex flex-col p-4 sm:p-6 overflow-y-auto custom-scrollbar transition-opacity duration-300 ${agentSettings.workspaceMode === 'CHAT' ? 'opacity-100 z-10' : 'opacity-0 pointer-events-none'}`} ref={scrollRef}>
          {messages.map((msg) => (
            <div key={msg.id} className={`group mb-8 animate-in fade-in slide-in-from-bottom-2 duration-300 flex flex-col ${msg.sender === 'YOU' ? 'items-end' : 'items-start'}`}>
              <div className={`flex items-baseline gap-3 mb-1 ${msg.sender === 'YOU' ? 'flex-row-reverse' : 'flex-row'}`}>
                <span className={`font-bold text-[10px] tracking-widest uppercase px-1.5 py-0.5 rounded-sm ${msg.sender === 'YOU' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'}`}>
                  {msg.sender === 'AGENT' ? agentSettings.agentName : msg.sender}:
                </span>
                <span className="text-[9px] text-gray-700 select-none tabular-nums">[{msg.timestamp}]</span>
              </div>
              
              <div className={`max-w-[85%] sm:max-w-[75%] px-4 border-l ${msg.sender === 'YOU' ? 'border-l-0 border-r text-right border-emerald-500/20' : 'border-l border-cyan-500/20'} mb-2`}>
                {msg.isImage ? (
                  <div className="relative group/img overflow-hidden rounded-lg border border-cyan-500/30 shadow-2xl cursor-pointer" onClick={() => onUpdateSettings({ ...agentSettings, canvas: { content: msg.text, type: 'image', title: 'Asset View' }, workspaceMode: 'CANVAS'})}>
                    <img src={msg.text} alt="Synth" className="max-w-full transition-transform duration-500 group-hover/img:scale-105" />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/img:opacity-100 transition-opacity flex items-center justify-center">
                       <span className="text-[10px] text-cyan-400 font-bold uppercase tracking-widest bg-black/80 px-4 py-2 rounded border border-cyan-500/30">Sync to Canvas</span>
                    </div>
                  </div>
                ) : (
                  <div className="text-gray-300 whitespace-pre-wrap break-words text-xs sm:text-sm leading-relaxed">{msg.text}</div>
                )}
                {msg.groundingUrls && msg.groundingUrls.length > 0 && (
                  <div className="mt-4 flex flex-wrap gap-2">
                    {msg.groundingUrls.map((url, i) => (
                      <button key={i} onClick={() => mountPortal(url)} className="flex items-center gap-1.5 text-[9px] text-cyan-400 hover:text-white transition-all bg-cyan-500/10 px-2 py-1 rounded border border-cyan-500/20 hover:border-cyan-400 shadow-sm">
                        <Globe size={10} /> OPEN_PORTAL_{i+1}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
          {isThinking && <div className="animate-pulse text-cyan-500/60 text-[10px] font-mono tracking-widest uppercase">Processing Neural Data...</div>}
        </div>

        {/* PORTAL VIEW */}
        <div className={`absolute inset-0 bg-[#050505] transition-opacity duration-300 ${agentSettings.workspaceMode === 'PORTAL' ? 'opacity-100 z-10' : 'opacity-0 pointer-events-none'}`}>
          <div className="h-full flex flex-col">
            <div className="bg-[#111] p-2 flex items-center gap-3 border-b border-gray-800">
              <div className="flex-grow bg-black/50 border border-gray-800 rounded px-3 py-1.5 flex items-center gap-3 overflow-hidden">
                <Globe size={12} className="text-cyan-600 flex-shrink-0" />
                <span className="text-[10px] text-gray-400 truncate font-mono uppercase tracking-widest">{agentSettings.portalUrl}</span>
              </div>
              <button onClick={() => window.open(agentSettings.portalUrl, '_blank')} className="text-gray-500 hover:text-cyan-400 p-1.5 transition-colors">
                <ExternalLink size={16} />
              </button>
            </div>
            <div className="flex-grow relative bg-[#0a0a0a]">
              <iframe src={agentSettings.portalUrl} className="w-full h-full border-none opacity-90 hover:opacity-100 transition-opacity" title="Neural Portal" />
            </div>
          </div>
        </div>

        {/* CANVAS VIEW */}
        <div className={`absolute inset-0 bg-[#080808] transition-opacity duration-300 ${agentSettings.workspaceMode === 'CANVAS' ? 'opacity-100 z-10' : 'opacity-0 pointer-events-none'}`}>
          <div className="h-full flex flex-col overflow-hidden">
            <div className="p-4 bg-[#111] border-b border-gray-800 flex justify-between items-center shadow-md">
              <div className="flex items-center gap-3">
                {agentSettings.canvas.type === 'code' ? <FileCode size={18} className="text-purple-400" /> : 
                 agentSettings.canvas.type === 'video' ? <Video size={18} className="text-red-400" /> :
                 agentSettings.canvas.type === 'image' ? <ImageIcon size={18} className="text-cyan-400" /> :
                 agentSettings.canvas.type === 'html' ? <Layout size={18} className="text-orange-400" /> : 
                 <FileText size={18} className="text-emerald-400" />}
                <span className="text-xs font-mono uppercase tracking-widest text-gray-400 font-bold">{agentSettings.canvas.title}</span>
                {agentSettings.canvas.language && <span className="text-[9px] bg-purple-500/10 text-purple-400 px-1.5 py-0.5 rounded border border-purple-500/20">{agentSettings.canvas.language.toUpperCase()}</span>}
              </div>
              <div className="text-[9px] text-gray-700 font-mono tracking-widest uppercase">
                WORKSPACE_LOCKED // SYNC_ACTIVE
              </div>
            </div>
            <div className="flex-grow relative p-6 sm:p-12 overflow-y-auto custom-scrollbar">
              <div className="max-w-5xl mx-auto w-full h-full">
                {renderCanvasContent()}
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Universal Input Bar */}
      <div className="relative z-40 p-4 border-t border-gray-800/50 flex items-center gap-3 bg-[#0a0a0a]/90 backdrop-blur-xl">
        <button className="p-2 text-gray-600 hover:text-emerald-500 transition-colors hidden sm:block" onClick={() => onSend("Summarize the attached document into the canvas workspace.")}>
          <Upload size={18} />
        </button>
        <div className="flex-grow relative group">
          <input 
            type="text" 
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            className="w-full bg-black/40 border border-gray-800 rounded px-4 py-3 text-gray-200 placeholder:text-gray-700 font-mono text-sm focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/10 transition-all shadow-inner" 
            placeholder={
              agentSettings.workspaceMode === 'PORTAL' ? "Send command to portal agent..." :
              agentSettings.workspaceMode === 'CANVAS' ? "Instruct workspace sync..." :
              "Enter neural directive..."
            } 
          />
        </div>
        <button onClick={handleSend} disabled={isThinking || !inputText.trim()} className="text-white bg-emerald-600 hover:bg-emerald-500 disabled:bg-gray-900 disabled:text-gray-700 px-5 py-3 rounded transition-all shadow-[0_0_20px_rgba(16,185,129,0.3)] active:scale-95 flex items-center justify-center gap-2 group border border-emerald-400/20">
          <Send size={16} />
          <span className="hidden sm:inline text-[10px] font-bold tracking-[0.2em] uppercase">Transmit</span>
        </button>
      </div>
    </main>
  );
};

export default ChatBox;
